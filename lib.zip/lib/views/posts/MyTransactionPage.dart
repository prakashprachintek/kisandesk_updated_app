import 'package:flutter/cupertino.dart';

class MyTransactionPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(child: Text("My Transactions coming soon."));
  }
}
