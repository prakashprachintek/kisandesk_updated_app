// PostDetailsPage.dart
import 'package:flutter/material.dart';

class PostDetailsPage extends StatelessWidget {
  final Map<String, dynamic> post;
  const PostDetailsPage({Key? key, required this.post}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    String title = post["title"] ?? "No Title";
    String description = post["description"] ?? "No Description available.";
    String imageUrl = post["imageUrl"] ?? "";
    String price = "₹${post["price"] ?? "0"}";
    String location = post["location"] ?? "Unknown Location";
    String category = post["category"] ?? "General";
    String postedBy = post["userId"] ?? "Anonymous";

    return Scaffold(
      appBar: AppBar(
        title: Text(title),
        backgroundColor: Color(0xFF00AD83),
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            imageUrl.isNotEmpty
                ? Image.network(
              imageUrl,
              fit: BoxFit.cover,
              width: double.infinity,
              height: 250,
            )
                : Container(height: 250, color: Colors.grey),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title,
                      style: TextStyle(
                          fontSize: 24, fontWeight: FontWeight.bold)),
                  SizedBox(height: 8),
                  Text(price,
                      style: TextStyle(
                          fontSize: 20,
                          color: Colors.green,
                          fontWeight: FontWeight.bold)),
                  SizedBox(height: 8),
                  Text("Category: $category",
                      style: TextStyle(
                          fontSize: 16, fontStyle: FontStyle.italic)),
                  SizedBox(height: 8),
                  Text("Location: $location", style: TextStyle(fontSize: 16)),
                  SizedBox(height: 16),
                  Text("Description:",
                      style:
                      TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  SizedBox(height: 4),
                  Text(description, style: TextStyle(fontSize: 16)),
                  SizedBox(height: 16),
                  Text("Posted by: $postedBy",
                      style: TextStyle(fontSize: 14, color: Colors.grey)),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}
