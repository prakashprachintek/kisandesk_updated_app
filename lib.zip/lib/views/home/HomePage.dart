import 'package:flutter/material.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:easy_localization/easy_localization.dart';
// Location packages
import 'package:geolocator/geolocator.dart';
import 'package:geocoding/geocoding.dart' as geocod;

// Adjust these imports for your actual file structure
import '../posts/CombinedDashboardPage.dart';
import '../profile/profile_page.dart';
import '../other/favoritePage.dart';
import '../marketplace/Mraket_page1.dart';
import '../marketplace/mandiRates.dart';
import '../whether/whetherinfo.dart';
import '../machinery/Machinery_Page.dart';
import '../cattle/Cattle_Page.dart';
import '../agriculture/Land_page.dart';
import '../laborers/LabourRequest.dart';
import '../other/add_page.dart';
import '../other/tabpage.dart';
import '../farmers/FarmerPage.dart';
import 'DashboardTab_page.dart';

/// A placeholder cart page if you don't have one
class CartPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("My Cart"),
      ),
      body: Center(
        child: Text("This is the Cart Page (placeholder)."),
      ),
    );
  }
}

/// ------------------- HOME PAGE ---------------------
class HomePage extends StatefulWidget {
  final Map<String, dynamic>? userData;
  final String? phoneNumber;

  const HomePage({
    Key? key,
    this.userData,
    this.phoneNumber,
  }) : super(key: key);

  @override
  _HomePageState createState() => _HomePageState();
}

/// -------------- STATE --------------
class _HomePageState extends State<HomePage> {
  int _selectedIndex = 0;

  /// The dynamic location name once fetched, e.g. "Bengaluru, KA"
  String? _locationName;

  @override
  void initState() {
    super.initState();
    _fetchLocation();
  }

  /// 1) Determine position using geolocator
  Future<Position> _determinePosition() async {
    bool serviceEnabled;
    LocationPermission permission;

    // Check if location services are enabled
    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      return Future.error('Location services are disabled.');
    }

    // Check permission
    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        return Future.error('Location permissions are denied.');
      }
    }

    if (permission == LocationPermission.deniedForever) {
      return Future.error(
        'Location permissions are permanently denied, we cannot request permission.',
      );
    }

    // If all good, get position
    return await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
  }

  /// 2) Reverse geocode to city, state
  Future<void> _fetchLocation() async {
    try {
      Position position = await _determinePosition();
      List<geocod.Placemark> placemarks = await geocod.placemarkFromCoordinates(
        position.latitude,
        position.longitude,
      );
      if (placemarks.isNotEmpty) {
        final place = placemarks[0];
        final city = place.locality ?? "Unknown City";
        final state = place.administrativeArea ?? "Unknown State";
        final locationStr = "$city, $state";

        setState(() {
          _locationName = locationStr;
        });
      } else {
        setState(() {
          _locationName = "Unknown Location";
        });
      }
    } catch (e) {
      setState(() {
        _locationName = "Location Error";
      });
      print("Error fetching location: $e");
    }
  }

  // Tapping avatar => to profile
  void _handleProfileTap() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ProfilePage(
          userData: widget.userData ?? {},
          phoneNumber: widget.phoneNumber ?? '',
        ),
      ),
    );
  }

  // Tapping cart => to a CartPage
  void _handleCartTap() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => CartPage()),
    );
  }

  // Bottom nav
  void _onItemTapped(int index) {
    setState(() => _selectedIndex = index);

    if (index == 2) {
      // Navigate to our new dashboard with tabs
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => CombinedDashboardPage(
            userData: widget.userData ?? {},
            phoneNumber: widget.phoneNumber ?? '',
          ),
        ),
      );

    }
    else if (index == 1) {
      // "Add"
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => AddMarketPostPage(
            userData: widget.userData ?? {},
            phoneNumber: widget.phoneNumber ?? '',
            isUserExists: true,
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // Full-screen gradient behind everything
      body: Stack(
        children: [
          // 1) Gradient from top to bottom
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  Color(0xFF1B5E20), // top dark green
                  Color(0xFF4CAF50),
                  Color(0xFFFFD600), // bottom bright yellow
                ],
                stops: [0.0, 0.4, 1.0],
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
              ),
            ),
          ),

          // 2) Main scrollable content
          SafeArea(
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  // (a) Top row: user avatar, language dropdown, favorites, cart
                  Padding(
                    padding: const EdgeInsets.only(left: 12, right: 12, top: 8, bottom: 8),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        InkWell(
                          onTap: _handleProfileTap,
                          child: CircleAvatar(
                            backgroundImage: AssetImage('assets/profile.jpg'),
                            radius: 20,
                          ),
                        ),
                        Row(
                          children: [
                            DropdownButtonHideUnderline(
                              child: DropdownButton<String>(
                                icon: Text(
                                  'A+',
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 18,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                items: <String>['Kannada', 'English', 'Hindi', 'Marathi']
                                    .map((String value) {
                                  return DropdownMenuItem<String>(
                                    value: value,
                                    child: Text(value),
                                  );
                                }).toList(),
                                onChanged: (String? newValue) {
                                  if (newValue != null) {
                                    Locale selectedLocale;
                                    switch (newValue.toLowerCase()) {
                                      case 'kannada':
                                        selectedLocale = Locale('kn');
                                        break;
                                      case 'english':
                                        selectedLocale = Locale('en');
                                        break;
                                      case 'hindi':
                                        selectedLocale = Locale('hi');
                                        break;
                                      case 'marathi':
                                        selectedLocale = Locale('mr');
                                        break;
                                      default:
                                        selectedLocale = Locale('en');
                                    }
                                    context.setLocale(selectedLocale);
                                  }
                                },
                              ),
                            ),
                            IconButton(
                              icon: Icon(Icons.favorite_border, color: Colors.white),
                              onPressed: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(builder: (context) => FavoritePage(favoriteItems: [])),
                                );
                              },
                            ),
                            IconButton(
                              icon: Icon(Icons.shopping_cart_outlined, color: Colors.white),
                              onPressed: _handleCartTap,
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),

                  // (b) Title, location, search
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          tr("Farmer Tech Store"),
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        SizedBox(height: 4),
                        // Show location
                        Row(
                          children: [
                            Icon(Icons.location_on, color: Colors.white, size: 16),
                            SizedBox(width: 4),
                            Text(
                              _locationName ?? "Fetching...",
                              style: TextStyle(color: Colors.white, fontSize: 14),
                            ),
                          ],
                        ),
                        SizedBox(height: 10),
                        // Search bar
                        Container(
                          height: 40,
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: TextField(
                            decoration: InputDecoration(
                              hintText: tr('Search products...'),
                              prefixIcon: Icon(Icons.search, color: Colors.grey),
                              border: InputBorder.none,
                              contentPadding: EdgeInsets.symmetric(vertical: 8),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 16),

                  // (c) White container for "body" layout
                  Container(
                    // White background with top corners
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(24),
                        topRight: Radius.circular(24),
                      ),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Column(
                        children: [
                          // 1) Carousel
                          _buildCarouselSlideshow(),
                          SizedBox(height: 16),

                          // 2) Categories
                          Align(
                            alignment: Alignment.centerLeft,
                            child: Text(
                              tr('Categories'),
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                color: Colors.black87,
                              ),
                            ),
                          ),
                          SizedBox(height: 8),
                          _buildCategoriesGrid(),

                          SizedBox(height: 16),
                          // 3) Deals of the Day
                          Align(
                            alignment: Alignment.centerLeft,
                            child: Text(
                              tr('Deals of the Day'),
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                color: Colors.black87,
                              ),
                            ),
                          ),
                          SizedBox(height: 8),
                          _buildDealsOfDay(),

                          SizedBox(height: 16),
                          // 4) Recommended
                          Align(
                            alignment: Alignment.centerLeft,
                            child: Text(
                              tr('Recommended'),
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                color: Colors.black87,
                              ),
                            ),
                          ),
                          SizedBox(height: 8),
                          _buildRecommendedRow(),

                          // Some bottom padding to avoid overflow behind the bottom nav
                          SizedBox(height: 80),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),

      // (d) BOTTOM NAV
      bottomNavigationBar: Stack(
        clipBehavior: Clip.none,
        children: [
          BottomNavigationBar(
            type: BottomNavigationBarType.fixed,
            backgroundColor: Color(0xFF00AD83),
            selectedItemColor: Colors.white,
            unselectedItemColor: Colors.white,
            currentIndex: _selectedIndex,
            onTap: _onItemTapped,
            items: <BottomNavigationBarItem>[
              BottomNavigationBarItem(
                icon: Icon(Icons.home),
                label: tr('Home'),
              ),
              BottomNavigationBarItem(
                icon: SizedBox.shrink(),
                label: '',
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.business_sharp),
                label: tr('Market'),
              ),
            ],
          ),
          Positioned(
            top: -24,
            left: MediaQuery.of(context).size.width / 2 - 30,
            child: GestureDetector(
              onTap: () => _onItemTapped(1),
              child: Column(
                children: [
                  Container(
                    height: 50,
                    width: 50,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.2),
                          blurRadius: 8,
                          offset: Offset(0, 3),
                        ),
                      ],
                    ),
                    child: Icon(
                      Icons.add,
                      size: 31,
                      color: Color(0xFF00AD83),
                    ),
                  ),
                  SizedBox(height: 4),
                  Text(
                    tr('Buy/Sell'),
                    style: TextStyle(
                      fontSize: 13.5,
                      color: Colors.white,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  /// -----------------------------------------
  /// Carousel (top slideshow)
  Widget _buildCarouselSlideshow() {
    final List<String> imageUrls = [
      'assets/image2.2.jpg',
      'assets/image1.webp',
      'assets/scrolimage3.jpg',
      'assets/image3.jpg',
    ];

    return Container(
      height: 150,
      child: CarouselSlider(
        options: CarouselOptions(
          height: 150,
          autoPlay: true,
          enlargeCenterPage: true,
          viewportFraction: 1.0,
        ),
        items: imageUrls.asMap().entries.map((entry) {
          final index = entry.key;
          final url = entry.value;
          return Builder(
            builder: (BuildContext context) {
              return GestureDetector(
                onTap: () {
                  if (index == 0) {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => MandiRatesPage()),
                    );
                  } else if (index == 1) {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => WeatherPage(
                          userData: widget.userData ?? {},
                          phoneNumber: widget.phoneNumber ?? '',
                        ),
                      ),
                    );
                  }
                },
                child: Container(
                  margin: EdgeInsets.symmetric(horizontal: 5),
                  decoration: BoxDecoration(
                    color: Colors.grey,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(12),
                    child: Image.asset(
                      url,
                      fit: BoxFit.cover,
                      width: double.infinity,
                    ),
                  ),
                ),
              );
            },
          );
        }).toList(),
      ),
    );
  }

  /// -----------------------------------------
  /// 6 Categories Grid
  Widget _buildCategoriesGrid() {
    final List<String> imagePaths = [
      'assets/shop2.webp',
      'assets/machines.webp',
      'assets/Agricultural Land.webp',
      'assets/Labor.jpeg',
      'assets/cattle.jpg',
      'assets/addatiimage3.jpg',
    ];
    final List<String> labels = [
      tr('Traders'),
      tr('Machinery'),
      tr('Land'),
      tr('Labours'),
      tr('Cattle'),
      tr('Crops'),
    ];

    return GridView.builder(
      shrinkWrap: true,
      physics: NeverScrollableScrollPhysics(),
      itemCount: 6,
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
        crossAxisSpacing: 10.0,
        mainAxisSpacing: 20.0,
        childAspectRatio: 1 / 1.2,
      ),
      itemBuilder: (context, index) {
        return _CategoryCard(
          imageUrl: imagePaths[index],
          label: labels[index],
          onTap: () => _handleCategoryTap(index),
        );
      },
    );
  }

  /// -----------------------------------------
  /// "Deals of the Day" horizontal slider
  Widget _buildDealsOfDay() {
    final List<_SimpleItem> deals = [
      _SimpleItem(title: "Fertilizer Combo", price: "\$25", image: "assets/pesticide.webp"),
      _SimpleItem(title: "Bulk Seeds", price: "\$40", image: "assets/addatiimage3.jpg"),
      _SimpleItem(title: "Tractor Tools", price: "\$55", image: "assets/machines.webp"),
      _SimpleItem(title: "Cow Feed", price: "\$20", image: "assets/cattle.jpg"),
    ];

    return Container(
      height: 150,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: deals.length,
        itemBuilder: (context, index) {
          final item = deals[index];
          return GestureDetector(
            onTap: () {
              // If you want to navigate somewhere else
            },
            child: Container(
              width: 130,
              margin: EdgeInsets.only(right: 12),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.1),
                    blurRadius: 5,
                    offset: Offset(2, 2),
                  ),
                ],
              ),
              child: Column(
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.vertical(top: Radius.circular(12)),
                    child: Image.asset(
                      item.image,
                      height: 80,
                      width: double.infinity,
                      fit: BoxFit.cover,
                    ),
                  ),
                  SizedBox(height: 4),
                  Text(
                    item.title,
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                  ),
                  SizedBox(height: 3),
                  Text(
                    item.price,
                    style: TextStyle(color: Colors.green[700], fontSize: 13),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  /// -----------------------------------------
  /// "Recommended" row
  Widget _buildRecommendedRow() {
    final List<_SimpleItem> recommendedItems = [
      _SimpleItem(title: "Pesticides", price: "\$15", image: "assets/pesticide.webp"),
      _SimpleItem(title: "Seeds", price: "\$20", image: "assets/addatiimage3.jpg"),
      _SimpleItem(title: "Harvest Tools", price: "\$35", image: "assets/machines.webp"),
      _SimpleItem(title: "Cattle Feed", price: "\$10", image: "assets/cattle.jpg"),
    ];

    return Container(
      height: 150,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: recommendedItems.length,
        itemBuilder: (context, index) {
          final item = recommendedItems[index];
          return GestureDetector(
            onTap: () {
              // Open item details or something
            },
            child: Container(
              width: 130,
              margin: EdgeInsets.only(right: 12),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.1),
                    blurRadius: 5,
                    offset: Offset(2, 2),
                  ),
                ],
              ),
              child: Column(
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.vertical(top: Radius.circular(12)),
                    child: Image.asset(
                      item.image,
                      height: 80,
                      width: double.infinity,
                      fit: BoxFit.cover,
                    ),
                  ),
                  SizedBox(height: 4),
                  Text(
                    item.title,
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                  ),
                  SizedBox(height: 3),
                  Text(
                    item.price,
                    style: TextStyle(color: Colors.green[700], fontSize: 13),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  /// Category Tapped
  void _handleCategoryTap(int index) {
    if (index == 0) {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => MarketPage(
            userData: widget.userData ?? {},
            phoneNumber: widget.phoneNumber ?? '',
          ),
        ),
      );
    } else if (index == 1) {
      Navigator.push(context, MaterialPageRoute(builder: (context) => MachineryPage()));
    } else if (index == 2) {
      Navigator.push(context, MaterialPageRoute(builder: (context) => LandPage()));
    } else if (index == 3) {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => LabourRequestPage(
            userData: widget.userData ?? {},
            phoneNumber: widget.phoneNumber ?? '',
          ),
        ),
      );
    } else if (index == 4) {
      Navigator.push(context, MaterialPageRoute(builder: (context) => CattlePage()));
    } else if (index == 5) {
      Navigator.push(context, MaterialPageRoute(builder: (context) => CropsPage()));
    }
  }
}

/// A simple card for categories
class _CategoryCard extends StatelessWidget {
  final String imageUrl;
  final String label;
  final VoidCallback onTap;

  const _CategoryCard({
    Key? key,
    required this.imageUrl,
    required this.label,
    required this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 280,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(15),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.2),
              spreadRadius: 1,
              blurRadius: 5,
              offset: Offset(3, 3),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // top image
            Expanded(
              flex: 7,
              child: Padding(
                padding: const EdgeInsets.all(3.0),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(15),
                  child: Image.asset(
                    imageUrl,
                    fit: BoxFit.cover,
                    width: double.infinity,
                    height: double.infinity,
                  ),
                ),
              ),
            ),
            // label
            Expanded(
              flex: 3,
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 8),
                alignment: Alignment.center,
                child: Text(
                  label,
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// A small item model for "Deals"/"Recommended"
class _SimpleItem {
  final String title;
  final String price;
  final String image;

  _SimpleItem({
    required this.title,
    required this.price,
    required this.image,
  });
}
