// LabourRequestsTab.dart
import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';

class LabourRequestsTab extends StatelessWidget {
  final Map<String, dynamic> userData;
  const LabourRequestsTab({Key? key, required this.userData}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // Reference to the "labourRequests" node in Firebase
    final DatabaseReference requestsRef = FirebaseDatabase.instance.ref("labourRequests");

    return StreamBuilder(
      stream: requestsRef.onValue,
      builder: (context, AsyncSnapshot snapshot) {
        if (!snapshot.hasData) {
          return Center(child: CircularProgressIndicator());
        }
        Map<dynamic, dynamic>? data = snapshot.data.snapshot.value as Map?;
        if (data == null) {
          return Center(child: Text("No Labour Requests Available"));
        }
        List<Map<String, dynamic>> requests = data.values
            .map((e) => Map<String, dynamic>.from(e))
            .toList();

        return ListView.builder(
          padding: const EdgeInsets.all(16.0),
          itemCount: requests.length,
          itemBuilder: (context, index) {
            final item = requests[index];
            return Card(
              margin: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 8.0),
              elevation: 4,
              child: Padding(
                padding: const EdgeInsets.all(12.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      item['work'] ?? 'No Work Description',
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                    ),
                    SizedBox(height: 8),
                    Text('From: ${item['work_date_from'] ?? 'N/A'}'),
                    Text('To: ${item['work_date_to'] ?? 'N/A'}'),
                    Text('Status: ${item['status'] ?? 'N/A'}'),
                    Text('Male Labour: ${item['total_male_labours'] ?? 0}'),
                    Text('Female Labour: ${item['total_female_labours'] ?? 0}'),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }
}
