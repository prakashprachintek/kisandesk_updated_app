import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:lottie/lottie.dart';

/// -------------- MAIN --------------
Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(MyApp());
}

/// -------------- APP --------------
class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Kisan Desk',
      debugShowCheckedModeBanner: false,
      theme: _buildThemeData(),
      home: SplashScreen(),
    );
  }

  ThemeData _buildThemeData() {
    return ThemeData(
      primaryColor: Color(0xFF1B5E20),
      colorScheme: ColorScheme.fromSwatch(primarySwatch: Colors.teal)
          .copyWith(secondary: Color(0xFFFFA000)),
      scaffoldBackgroundColor: Colors.white,
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          foregroundColor: Colors.white,
          backgroundColor: Color(0xFF1B5E20),
          minimumSize: Size.fromHeight(48),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(8),
          ),
          textStyle: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 14),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: BorderSide(color: Color(0xFF1B5E20), width: 2),
        ),
        labelStyle: TextStyle(color: Colors.grey[700]),
      ),
    );
  }
}

/// ****************** SPLASH SCREEN ******************
class SplashScreen extends StatefulWidget {
  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    // Show ~3s, then Onboarding
    Future.delayed(Duration(seconds: 3), () {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => OnboardingScreen()),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Larger Lottie
            Lottie.asset('assets/animations/logo.json', width: 200, height: 400),
            SizedBox(height: 16),
            Text(
              "Kisan Desk",
              style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold, color: Color(0xFF1B5E20)),
            ),
          ],
        ),
      ),
    );
  }
}

/// ****************** ONBOARDING SCREEN ******************
class OnboardingScreen extends StatefulWidget {
  @override
  _OnboardingScreenState createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final PageController _pageController = PageController();
  int _currentIndex = 0;

  final List<String> onboardingTexts = [
    "Buy & Sell Agricultural Crops with Ease",
    "Find the Best Machinery & Equipment",
    "Connect with Dealers & Manufacturers",
  ];
  final List<String> onboardingFiles = [
    "assets/animations/onb1.json",
    "assets/animations/onb2.json",
    "assets/animations/onb3.json",
  ];

  void _nextPage() {
    if (_currentIndex < onboardingFiles.length - 1) {
      _pageController.nextPage(duration: Duration(milliseconds: 500), curve: Curves.easeIn);
    }
  }

  void _skip() {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => AuthSelectionScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Stack(
        children: [
          PageView.builder(
            controller: _pageController,
            itemCount: onboardingFiles.length,
            onPageChanged: (index) => setState(() => _currentIndex = index),
            itemBuilder: (context, index) {
              return SafeArea(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Lottie.asset(onboardingFiles[index], width: 300, height: 300),
                    SizedBox(height: 20),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 32),
                      child: Text(
                        onboardingTexts[index],
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFF1B5E20),
                        ),
                      ),
                    ),
                    SizedBox(height: 40),
                    if (index == onboardingFiles.length - 1)
                      _GradientButton(
                        text: "Get Started",
                        onPressed: () {
                          Navigator.pushReplacement(
                            context,
                            MaterialPageRoute(builder: (_) => AuthSelectionScreen()),
                          );
                        },
                      )
                  ],
                ),
              );
            },
          ),
          // Skip top-right
          Positioned(
            top: 40,
            right: 20,
            child: GestureDetector(
              onTap: _skip,
              child: Text(
                "Skip",
                style: TextStyle(fontSize: 16, color: Color(0xFF1B5E20), fontWeight: FontWeight.bold),
              ),
            ),
          ),
          // Next bottom-center if not last
          if (_currentIndex < onboardingFiles.length - 1)
            Positioned(
              bottom: 40,
              left: 0,
              right: 0,
              child: Center(
                child: _GradientButton(
                  text: "Next",
                  onPressed: _nextPage,
                ),
              ),
            ),
        ],
      ),
    );
  }
}

/// Single gradient button used in Onboarding
class _GradientButton extends StatelessWidget {
  final String text;
  final VoidCallback onPressed;
  const _GradientButton({Key? key, required this.text, required this.onPressed})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(8),
      onTap: onPressed,
      child: Container(
        width: 120,
        height: 48,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              Color(0xFF1B5E20),
              Color(0xFF4CAF50),
              Color(0xFFFFD600),
            ],
            stops: [0.0, 0.5, 1.0],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(8),
        ),
        alignment: Alignment.center,
        child: Text(
          text,
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
      ),
    );
  }
}

/// A triple gradient for the top bar in AuthSelection
BoxDecoration topGradient() {
  return BoxDecoration(
    gradient: LinearGradient(
      colors: [
        Color(0xFF1B5E20),
        Color(0xFF4CAF50),
        Color(0xFFFFD600),
      ],
      stops: [0.0, 0.5, 1.0],
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
    ),
  );
}

/// ****************** AUTH SELECTION SCREEN ******************
class AuthSelectionScreen extends StatelessWidget {
  const AuthSelectionScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Column(
          children: [

            // White area
            Expanded(
              child: SingleChildScrollView(
                padding: EdgeInsets.symmetric(horizontal: 20, vertical: 20),
                child: Column(
                  children: [
                    SizedBox(height: 16),
                    SizedBox(
                      width: 200,
                      height: 200,
                      child: Lottie.asset('assets/animations/login.json'),
                    ),
                    SizedBox(height: 16),

                    Text(
                      "Welcome to Kisan Desk!",
                      style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Color(0xFF1B5E20)),
                      textAlign: TextAlign.center,
                    ),
                    SizedBox(height: 8),
                    Text(
                      "Choose your preferred sign-in method below",
                      style: TextStyle(fontSize: 14, color: Colors.grey[700]),
                      textAlign: TextAlign.center,
                    ),
                    SizedBox(height: 24),

                    _AuthOptionCard(
                      lottieFile: 'assets/animations/phone.json',
                      title: "Mobile OTP",
                      subtitle: "Login with your phone number",
                      onTap: () {
                        Navigator.push(context, MaterialPageRoute(builder: (_) => MobileVerificationScreen()));
                      },
                    ),
                    SizedBox(height: 20),
                    _AuthOptionCard(
                      lottieFile: 'assets/animations/google.json',
                      title: "Google Account",
                      subtitle: "Use your Google account to sign in",
                      onTap: () {
                        Navigator.push(context, MaterialPageRoute(builder: (_) => GoogleSignInHandler()));
                      },
                    ),
                    SizedBox(height: 20),
                    _AuthOptionCard(
                      lottieFile: 'assets/animations/email.json',
                      title: "Email & Password",
                      subtitle: "Sign in or register with your email",
                      onTap: () {
                        Navigator.push(context, MaterialPageRoute(builder: (_) => EmailAuthSelectionScreen()));
                      },
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// A card widget for sign-in options
class _AuthOptionCard extends StatelessWidget {
  final String lottieFile;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  const _AuthOptionCard({
    Key? key,
    required this.lottieFile,
    required this.title,
    required this.subtitle,
    required this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(16),
      onTap: onTap,
      child: Container(
        width: double.infinity,
        margin: EdgeInsets.symmetric(horizontal: 4),
        padding: EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.9),
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: Colors.black12,
              blurRadius: 8,
              offset: Offset(2, 4),
            )
          ],
        ),
        child: Row(
          children: [
            SizedBox(
              width: 60,
              height: 60,
              child: Lottie.asset(lottieFile),
            ),
            SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFF1B5E20)),
                  ),
                  SizedBox(height: 4),
                  Text(
                    subtitle,
                    style: TextStyle(fontSize: 14, color: Colors.grey[700]),
                  ),
                ],
              ),
            ),
            Icon(Icons.arrow_forward_ios, color: Colors.grey[600], size: 18),
          ],
        ),
      ),
    );
  }
}

/// ****************** MOBILE OTP FLOW ******************
class MobileVerificationScreen extends StatefulWidget {
  @override
  _MobileVerificationScreenState createState() => _MobileVerificationScreenState();
}

class _MobileVerificationScreenState extends State<MobileVerificationScreen> {
  final TextEditingController phoneController = TextEditingController();
  final FirebaseAuth _auth = FirebaseAuth.instance;

  bool isValid10Digit(String phone) {
    final regex = RegExp(r'^\d{10}$');
    return regex.hasMatch(phone);
  }

  Future<void> verifyPhoneNumber() async {
    final digitsOnly = phoneController.text.trim();
    if (!isValid10Digit(digitsOnly)) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Invalid phone number. Enter 10 digits.")),
      );
      return;
    }
    final phoneNumber = "+91$digitsOnly";

    await _auth.verifyPhoneNumber(
      phoneNumber: phoneNumber,
      verificationCompleted: (PhoneAuthCredential credential) async {
        try {
          await _auth.signInWithCredential(credential);
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (_) => HomeScreen(phoneNumber: phoneNumber, userData: {})),
          );
        } catch (e) {
          print("Auto sign-in failed: $e");
        }
      },
      verificationFailed: (FirebaseAuthException e) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Verification failed: ${e.message}")));
      },
      codeSent: (String verificationId, int? resendToken) {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => OTPVerificationScreen(
              verificationId: verificationId,
              phoneNumber: phoneNumber,
            ),
          ),
        );
      },
      codeAutoRetrievalTimeout: (String verificationId) {
        print("Auto retrieval timed out: $verificationId");
      },
    );
  }

  @override
  void dispose() {
    phoneController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // White AppBar with back arrow
      appBar: AppBar(
        title: Text("Mobile Verification", style: TextStyle(color: Colors.grey[700])),
        backgroundColor: Colors.white,
        elevation: 0,
        iconTheme: IconThemeData(color: Colors.grey[700]),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 30),
        child: Column(
          children: [
            SizedBox(height: 16),
            Lottie.asset("assets/animations/phone.json", width: 180, height: 180),
            SizedBox(height: 20),

            Text(
              "Enter Your Phone Number",
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Color(0xFF1B5E20)),
            ),
            SizedBox(height: 12),
            Text(
              "We'll send an OTP to verify your number (+91)",
              style: TextStyle(fontSize: 14, color: Colors.grey[700]),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 40),

            TextField(
              controller: phoneController,
              keyboardType: TextInputType.phone,
              decoration: InputDecoration(
                labelText: "10-digit number",
                prefixIcon: Icon(Icons.phone, color: Colors.grey[700]),
                fillColor: Colors.white,
                filled: true,
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
              ),
            ),
            SizedBox(height: 24),

            _GradientAuthButton(
              text: "Send OTP",
              onTap: verifyPhoneNumber,
            ),
            Spacer(),

            Text("Need Help?", style: TextStyle(color: Colors.grey[700])),
            SizedBox(height: 16),
          ],
        ),
      ),
    );
  }
}

class OTPVerificationScreen extends StatefulWidget {
  final String verificationId;
  final String phoneNumber;

  const OTPVerificationScreen({
    Key? key,
    required this.verificationId,
    required this.phoneNumber,
  }) : super(key: key);

  @override
  _OTPVerificationScreenState createState() => _OTPVerificationScreenState();
}

class _OTPVerificationScreenState extends State<OTPVerificationScreen> {
  final TextEditingController otpController = TextEditingController();
  final FirebaseAuth _auth = FirebaseAuth.instance;

  Future<void> verifyOTP() async {
    final otp = otpController.text.trim();
    if (otp.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("OTP cannot be empty")));
      return;
    }
    try {
      final credential = PhoneAuthProvider.credential(
        verificationId: widget.verificationId,
        smsCode: otp,
      );
      await _auth.signInWithCredential(credential);

      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => HomeScreen(phoneNumber: widget.phoneNumber, userData: {})),
      );
    } catch (e) {
      print("OTP Verification failed: $e");
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("OTP Verification failed: $e")));
    }
  }

  @override
  void dispose() {
    otpController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // White AppBar
      appBar: AppBar(
        title: Text("OTP Verification", style: TextStyle(color: Colors.grey[700])),
        backgroundColor: Colors.white,
        elevation: 0,
        iconTheme: IconThemeData(color: Colors.grey[700]),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 30),
        child: Column(
          children: [
            SizedBox(height: 16),
            Lottie.asset("assets/animations/lock.json", width: 180, height: 180),
            SizedBox(height: 20),

            Text(
              "Enter OTP",
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Color(0xFF1B5E20)),
            ),
            SizedBox(height: 12),
            Text(
              "OTP sent to: ${widget.phoneNumber}",
              style: TextStyle(fontSize: 14, color: Colors.grey[700]),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 40),

            TextField(
              controller: otpController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: "6-digit OTP",
                prefixIcon: Icon(Icons.password, color: Colors.grey[700]),
                fillColor: Colors.white,
                filled: true,
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
              ),
            ),
            SizedBox(height: 24),

            _GradientAuthButton(
              text: "Verify OTP",
              onTap: verifyOTP,
            ),
            Spacer(),

            Text("Wrong number? Go back", style: TextStyle(color: Colors.grey[700])),
            SizedBox(height: 16),
          ],
        ),
      ),
    );
  }
}

/// ****************** GOOGLE SIGN-IN FLOW ******************
class GoogleSignInHandler extends StatefulWidget {
  @override
  _GoogleSignInHandlerState createState() => _GoogleSignInHandlerState();
}

class _GoogleSignInHandlerState extends State<GoogleSignInHandler> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final GoogleSignIn _googleSignIn = GoogleSignIn();

  @override
  void initState() {
    super.initState();
    _signInWithGoogle();
  }

  Future<void> _signInWithGoogle() async {
    try {
      final googleUser = await _googleSignIn.signIn();
      if (googleUser == null) {
        Navigator.pop(context); // user canceled
        return;
      }
      final googleAuth = await googleUser.authentication;
      final credential = GoogleAuthProvider.credential(
        accessToken: googleAuth.accessToken,
        idToken: googleAuth.idToken,
      );
      await _auth.signInWithCredential(credential);

      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => HomeScreen(
          phoneNumber: '',
          userData: {
            "email": _auth.currentUser?.email,
            "displayName": _auth.currentUser?.displayName,
          },
        )),
      );
    } catch (e) {
      print("Google Sign-In failed: $e");
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Google Sign-In failed: $e")));
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // White AppBar
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        title: Text("Google Sign-In", style: TextStyle(color: Colors.grey[700])),
        iconTheme: IconThemeData(color: Colors.grey[700]),
      ),
      body: Center(
        child: Lottie.asset("assets/animations/google.json", width: 180, height: 180),
      ),
    );
  }
}

/// ****************** EMAIL & PASSWORD FLOW ******************
class EmailAuthSelectionScreen extends StatelessWidget {
  const EmailAuthSelectionScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // White background
      appBar: AppBar(
        title: Text("Email / Password Auth", style: TextStyle(color: Colors.grey[700])),
        backgroundColor: Colors.white,
        elevation: 0,
        iconTheme: IconThemeData(color: Colors.grey[700]),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            Lottie.asset("assets/animations/email.json", width: 180, height: 180),
            SizedBox(height: 20),
            Text(
              "Sign in or create an account with email",
              style: TextStyle(fontSize: 14, color: Colors.grey[700]),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 40),
            _GradientAuthButton(
              text: "Sign In with Email",
              onTap: () {
                Navigator.push(context, MaterialPageRoute(builder: (_) => EmailSignInScreen()));
              },
            ),
            SizedBox(height: 20),
            _GradientAuthButton(
              text: "Sign Up (Register) with Email",
              onTap: () {
                Navigator.push(context, MaterialPageRoute(builder: (_) => EmailSignUpScreen()));
              },
            ),
          ],
        ),
      ),
    );
  }
}

class EmailSignInScreen extends StatefulWidget {
  @override
  _EmailSignInScreenState createState() => _EmailSignInScreenState();
}

class _EmailSignInScreenState extends State<EmailSignInScreen> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final emailCtrl = TextEditingController();
  final passCtrl = TextEditingController();

  Future<void> _signIn() async {
    final email = emailCtrl.text.trim();
    final pass = passCtrl.text.trim();
    if (email.isEmpty || pass.isEmpty) {
      _showError("Please fill in both email and password");
      return;
    }
    try {
      final userCred = await _auth.signInWithEmailAndPassword(email: email, password: pass);
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => HomeScreen(
          phoneNumber: '',
          userData: {"email": userCred.user?.email},
        )),
      );
    } catch (e) {
      _showError("Sign-In failed: $e");
    }
  }

  void _showError(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  @override
  void dispose() {
    emailCtrl.dispose();
    passCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // White AppBar
      appBar: AppBar(
        title: Text("Sign In with Email", style: TextStyle(color: Colors.grey[700])),
        backgroundColor: Colors.white,
        elevation: 0,
        iconTheme: IconThemeData(color: Colors.grey[700]),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            Lottie.asset("assets/animations/email.json", width: 180, height: 180),
            SizedBox(height: 20),
            Text(
              "Enter your email and password",
              style: TextStyle(fontSize: 14, color: Colors.grey[700]),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 40),

            TextField(
              controller: emailCtrl,
              decoration: InputDecoration(
                labelText: "Email",
                prefixIcon: Icon(Icons.email, color: Colors.grey[700]),
                fillColor: Colors.white,
                filled: true,
              ),
            ),
            SizedBox(height: 16),
            TextField(
              controller: passCtrl,
              obscureText: true,
              decoration: InputDecoration(
                labelText: "Password",
                prefixIcon: Icon(Icons.lock, color: Colors.grey[700]),
                fillColor: Colors.white,
                filled: true,
              ),
            ),
            SizedBox(height: 24),

            _GradientAuthButton(
              text: "Sign In",
              onTap: _signIn,
            ),
          ],
        ),
      ),
    );
  }


}

class EmailSignUpScreen extends StatefulWidget {
  @override
  _EmailSignUpScreenState createState() => _EmailSignUpScreenState();
}

class _EmailSignUpScreenState extends State<EmailSignUpScreen> {
  final FirebaseAuth _auth = FirebaseAuth.instance;

  final fullNameCtrl = TextEditingController();
  final emailCtrl = TextEditingController();
  final passCtrl = TextEditingController();

  Future<void> _signUp() async {
    final fullName = fullNameCtrl.text.trim();
    final email = emailCtrl.text.trim();
    final pass = passCtrl.text.trim();

    if (fullName.isEmpty || email.isEmpty || pass.isEmpty) {
      _showError("Please fill in full name, email, and password");
      return;
    }

    try {
      final userCred = await _auth.createUserWithEmailAndPassword(email: email, password: pass);

      // Save to Firestore
      if (userCred.user != null) {
        await FirebaseFirestore.instance
            .collection('users')
            .doc(userCred.user!.uid)
            .set({
          'fullName': fullName,
          'email': email,
          'createdAt': DateTime.now(),
        });
      }

      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) => HomeScreen(
            phoneNumber: '',
            userData: {
              "email": userCred.user?.email,
              "fullName": fullName
            },
          ),
        ),
      );
    } catch (e) {
      _showError("Sign-Up failed: $e");
    }
  }

  void _showError(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  @override
  void dispose() {
    fullNameCtrl.dispose();
    emailCtrl.dispose();
    passCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // White AppBar
      appBar: AppBar(
        title: Text("Sign Up with Email", style: TextStyle(color: Colors.grey[700])),
        backgroundColor: Colors.white,
        elevation: 0,
        iconTheme: IconThemeData(color: Colors.grey[700]),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            Lottie.asset("assets/animations/email.json", width: 180, height: 180),
            SizedBox(height: 20),
            Text(
              "Enter your name, valid email, & set a strong password",
              style: TextStyle(fontSize: 14, color: Colors.grey[700]),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 40),

            // Full Name
            TextField(
              controller: fullNameCtrl,
              decoration: InputDecoration(
                labelText: "Full Name",
                prefixIcon: Icon(Icons.person, color: Colors.grey[700]),
                fillColor: Colors.white,
                filled: true,
              ),
            ),
            SizedBox(height: 16),

            // Email
            TextField(
              controller: emailCtrl,
              decoration: InputDecoration(
                labelText: "Email",
                prefixIcon: Icon(Icons.email, color: Colors.grey[700]),
                fillColor: Colors.white,
                filled: true,
              ),
            ),
            SizedBox(height: 16),

            // Password
            TextField(
              controller: passCtrl,
              obscureText: true,
              decoration: InputDecoration(
                labelText: "Password",
                prefixIcon: Icon(Icons.lock, color: Colors.grey[700]),
                fillColor: Colors.white,
                filled: true,
              ),
            ),
            SizedBox(height: 24),

            _GradientAuthButton(
              text: "Create Account",
              onTap: _signUp,
            ),
          ],
        ),
      ),
    );
  }
}

/// A single gradient button used in auth screens
class _GradientAuthButton extends StatelessWidget {
  final String text;
  final VoidCallback onTap;

  const _GradientAuthButton({Key? key, required this.text, required this.onTap})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(8),
      onTap: onTap,
      child: Container(
        width: double.infinity,
        height: 48,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              Color(0xFF1B5E20),
              Color(0xFF4CAF50),
              Color(0xFFFFD600),
            ],
            stops: [0.0, 0.5, 1.0],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(8),
        ),
        alignment: Alignment.center,
        child: Text(
          text,
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
      ),
    );
  }
}

/// ****************** HOME SCREEN ******************
class HomePage extends StatelessWidget {
  final String phoneNumber;
  final Map<String, dynamic> userData;

  const HomePage({Key? key, required this.phoneNumber, required this.userData})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    // Display phoneNumber & userData
    return Scaffold(
      appBar: AppBar(
        title: Text("Home Page"),
        backgroundColor: Color(0xFF1B5E20),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text("Welcome to Home!", style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
            SizedBox(height: 10),
            if (phoneNumber.isNotEmpty) Text("Phone: $phoneNumber"),
            if (userData.isNotEmpty) Text("UserData: $userData"),
          ],
        ),
      ),
    );
  }
}

class HomeScreen extends StatelessWidget {
  final String phoneNumber;
  final Map<String, dynamic> userData;

  const HomeScreen({Key? key, required this.phoneNumber, required this.userData})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return HomePage(phoneNumber: phoneNumber, userData: userData);
  }
}
